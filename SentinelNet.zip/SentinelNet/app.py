from flask import Flask, render_template, request, jsonify
import joblib
import pandas as pd
import numpy as np
import os
import time
import threading
import json
from datetime import datetime

app = Flask(__name__)

# ── Fix numpy JSON serialization ──────────────────────────────────────────────
class NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):  return int(obj)
        if isinstance(obj, np.floating): return float(obj)
        if isinstance(obj, np.ndarray):  return obj.tolist()
        if isinstance(obj, np.bool_):    return bool(obj)
        return super().default(obj)

app.json_encoder = NpEncoder

# ── Load model and encoder ────────────────────────────────────────────────────
sentinel_brain = joblib.load('./models/sentinel_brain.joblib')
le             = joblib.load('./models/label_encoder.joblib')

# ── Decode integer labels to class name strings ───────────────────────────────
def decode_label(val):
    """Convert integer or string label to class name."""
    try:
        i = int(val)
        if 0 <= i < len(le.classes_):
            return str(le.classes_[i])
    except (ValueError, TypeError):
        pass
    return str(val)

SEVERITY_MAP = {
    'normal' : 'None',
    'DoS'    : 'Critical',
    'Probe'  : 'Medium',
    'R2L'    : 'High',
    'U2R'    : 'Critical',
}

# ── Live simulation state ─────────────────────────────────────────────────────
live_state = {
    'running'   : False,
    'alerts'    : [],
    'total'     : 0,
    'intrusions': 0,
    'batch'     : 0
}

TEST_DATA_PATH = './data/data/processed/test_processed_advanced.csv'

# ─────────────────────────────────────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload')
def upload_page():
    return render_template('upload.html')

@app.route('/live')
def live_page():
    return render_template('live.html')


# ── Upload & Predict ──────────────────────────────────────────────────────────
@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    try:
        df = pd.read_csv(file)

        # Extract and decode true labels if present
        if 'attack_class' in df.columns:
            raw_true    = df['attack_class'].values
            true_labels = [decode_label(v) for v in raw_true]
            df = df.drop(columns=['attack_class'])
        else:
            true_labels = None

        # Keep only numeric columns
        df = df.select_dtypes(include=[np.number])
        X  = df.values

        preds      = sentinel_brain.predict(X)
        proba      = sentinel_brain.predict_proba(X)
        confidence = proba.max(axis=1)
        pred_names = [decode_label(p) for p in preds]

        results  = []
        by_class = {}
        by_sev   = {}

        for i in range(len(pred_names)):
            cls      = str(pred_names[i])
            severity = SEVERITY_MAP.get(cls, 'Unknown')
            true_val = true_labels[i] if true_labels is not None else 'N/A'

            results.append({
                'id'        : int(i + 1),
                'predicted' : cls,
                'true'      : str(true_val),
                'confidence': round(float(confidence[i]) * 100, 1),
                'severity'  : severity,
                'intrusion' : bool(cls != 'normal')
            })
            by_class[cls]      = by_class.get(cls, 0) + 1
            by_sev[severity]   = by_sev.get(severity, 0) + 1

        total      = len(results)
        intrusions = sum(1 for r in results if r['intrusion'])

        return jsonify({
            'results'    : results[:200],
            'total'      : int(total),
            'intrusions' : int(intrusions),
            'normal'     : int(total - intrusions),
            'by_class'   : by_class,
            'by_severity': by_sev
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ── Live Simulation ───────────────────────────────────────────────────────────
def run_live_simulation():
    global live_state
    try:
        df_test = pd.read_csv(TEST_DATA_PATH)
        if 'attack_class' in df_test.columns:
            df_test = df_test.drop(columns=['attack_class'])
        df_test = df_test.select_dtypes(include=[np.number])
        X = df_test.values

        BATCH         = 50
        total_batches = len(X) // BATCH
        live_state['alerts']     = []
        live_state['total']      = 0
        live_state['intrusions'] = 0
        live_state['batch']      = 0

        for b in range(total_batches):
            if not live_state['running']:
                break

            start      = b * BATCH
            X_b        = X[start:start + BATCH]
            preds      = sentinel_brain.predict(X_b)
            proba      = sentinel_brain.predict_proba(X_b)
            confidence = proba.max(axis=1)
            pred_names = [decode_label(p) for p in preds]
            ts         = datetime.now().strftime('%H:%M:%S')

            for i in range(BATCH):
                cls      = str(pred_names[i])
                severity = SEVERITY_MAP.get(cls, 'Unknown')
                is_intr  = cls != 'normal'

                live_state['alerts'].append({
                    'id'        : int(start + i + 1),
                    'time'      : ts,
                    'predicted' : cls,
                    'confidence': round(float(confidence[i]) * 100, 1),
                    'severity'  : severity,
                    'intrusion' : bool(is_intr)
                })
                live_state['total'] += 1
                if is_intr:
                    live_state['intrusions'] += 1

            if len(live_state['alerts']) > 100:
                live_state['alerts'] = live_state['alerts'][-100:]

            live_state['batch'] = b + 1
            time.sleep(0.8)

    except Exception as e:
        print(f'Simulation error: {e}')
    finally:
        live_state['running'] = False


@app.route('/live/start', methods=['POST'])
def live_start():
    global live_state
    if live_state['running']:
        return jsonify({'status': 'already running'})
    live_state['running'] = True
    threading.Thread(target=run_live_simulation, daemon=True).start()
    return jsonify({'status': 'started'})

@app.route('/live/stop', methods=['POST'])
def live_stop():
    live_state['running'] = False
    return jsonify({'status': 'stopped'})

@app.route('/live/status')
def live_status():
    alerts   = live_state['alerts'][-20:]
    by_class = {}
    by_sev   = {}
    for a in live_state['alerts']:
        by_class[a['predicted']] = by_class.get(a['predicted'], 0) + 1
        by_sev[a['severity']]    = by_sev.get(a['severity'], 0) + 1

    return jsonify({
        'running'    : live_state['running'],
        'total'      : int(live_state['total']),
        'intrusions' : int(live_state['intrusions']),
        'normal'     : int(live_state['total'] - live_state['intrusions']),
        'batch'      : int(live_state['batch']),
        'alerts'     : alerts,
        'by_class'   : by_class,
        'by_severity': by_sev
    })


if __name__ == '__main__':
    app.run(debug=True, port=5000)
